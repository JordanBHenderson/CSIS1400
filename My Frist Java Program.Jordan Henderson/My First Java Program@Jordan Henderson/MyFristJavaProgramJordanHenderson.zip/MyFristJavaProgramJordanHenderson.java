
package my.frist.java.program.jordan.henderson;


public class MyFristJavaProgramJordanHenderson
{

    
    public static void main(String[] args)
    {
        int x;
        
        System.out.println("This is fun");
    
        x = 0; 
    }
    

}
